// Importeer de Express-module (een framework voor het bouwen van webservers in Node.js)
import express, { request, response } from 'express';
import routes from "./routes/index.mjs"
import cookieParser from 'cookie-parser';
import session from 'express-session';
import { MockUsers } from './utils/constants.mjs';
import { body } from 'express-validator';
import passport from 'passport';
import "./strategies/local-strategies.mjs";

// Maak een nieuwe Express-applicatie genaamd app
const app = express();





// gebruiken van express.json en de routes
app.use(express.json());
app.use(cookieParser());
app.use(session({
    secret: 'jurgen the dev',
    saveUninitialized: false,
    resave: false,
    cookie: {
        maxAge: 60000 * 60,
    },
}));
app.use(routes);


app.use(passport.initialize());
app.use(passport.session());


app.post('/api/auth', passport.authenticate("local"), (request, response) => {
    response.sendStatus(200);
});

// Stel de poort in waarop de server draait. Gebruik de waarde uit de omgevingsvariabele 'PORT', of standaard poort 3000 als deze niet is ingesteld.
const PORT = process.env.PORT || 3000;



// voorbeeld get request
app.get("/", (request, response) => {
    console.log(request.session);
    console.log(request.session.id);
    request.session.visited = true;
    response.cookie('hello','world', {maxAge: 60000 * 60});
    response.status(201).send("hello world!");
});



app.post('/api/auth', (request, response) => {
    const {body: {username, password}, } = request;

    const finduser = MockUsers.find((hallo) => hallo.username == username);
    if (!finduser || finduser.password !== password) 
        return response.status(401).send({msg: "Bad credentials"});

    request.session.user = finduser;
    return response.status(200).send(finduser);
});



app.get('/api/auth/status', (request, response) => {
    return (request.user) ? response.send(request.user) : response.sendStatus(401);

});


app.post("/api/auth/logout", (request, response) => {
    if (!request.user) return response.sendStatus(401);
    request.logout((err) => {
        if (err) return response.sendStatus(400);
        response.send(200);
    });
});


// winkelwagen voorbeeld
app.post("/api/cart", (request, response) => {
    if (!request.session.user) return response.sendStatus(401);
    const { body: item} = request;

    const {cart} = request.session; ( cart)? cart.push(item): request.session.cart = [item];
    
    return response.status(201).send(item);
})



// get request winkelwagen
app.get("/api/cart", (request, response) => {
    if (!request.session.user) return response.sendStatus(401);
    return response.send(request.session.cart ?? []);

});



const cijfer = 2;


app.post("/api/cijfer", (request,response) => {
    const { body } = request; // Body van de request ophalen
    const getal = body.hallo;
    console.log(cijfer);
    const intgetal = parseInt(getal,10);
    console.log(intgetal);

    if (intgetal !== cijfer) return response.status(400).send({msg: "getal komt niet overeen"});

    return response.status(200).send({msg: "getal komt overeen"});
});

// Start de server en laat luisteren op de ingestelde poort. Log een bericht wanneer de server draait.
app.listen(PORT, () => {
    console.log(`Running on port ${PORT}`); // Print de actieve poort in de console.
});


