import { MockUsers } from "./constants.mjs";
import rateLimit from 'express-rate-limit'; // Importeren van express-rate-limit

//midelware code functie voor het opzoeken van een id
export const resolveIndexByUserId = (request, response, next) => {
    const{params: {id}} = request;

    const parseId = parseInt(id);
    if (isNaN(parseId)) return response.status(400).send("Bad request");
    const findUserIndex = MockUsers.findIndex(
        (user) => user.id === parseId
    );

    if(findUserIndex === -1) return response.sendStatus(404);
    request.findUserIndex = findUserIndex;
    next();
};



// Rate-limiting configureren
export const userCreationLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minuten
    max: 100, // Maximaal 100 verzoeken per IP
    message: 'Too many accounts created from this IP, please try again later',
});