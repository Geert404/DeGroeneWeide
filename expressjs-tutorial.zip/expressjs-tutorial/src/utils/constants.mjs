export const MockUsers =[
    {id: 1, username: "jurgen", displayName: "kat", password: "jurgen"},
    {id: 2, username: "henk", displayName: "man", password: "hallo2"},
    {id: 3, username: "toyota", displayName: "auto", password: "hallo3"}
    ];