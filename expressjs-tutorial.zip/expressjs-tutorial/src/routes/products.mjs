import { Router } from "express";

const router = Router();

router.get("/api/products", (request, response) => {
    console.log(request.headers.cookie);
    console.log(request.cookies);
    if (request.cookies.hello && request.cookies.hello === 'world')
        return response.send([{ id: 123, name: "pizza", price: 12.99}]);

    return response.send({ msg: "sorry voor jouw geen cookies !!!!"});
});

export default router;

// POST productID, catecoryID(optional), name, Price, Size(liter kg), AmountinStock

// Get product ID

