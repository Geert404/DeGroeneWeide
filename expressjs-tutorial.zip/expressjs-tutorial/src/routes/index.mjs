import { Router } from "express";
import usersRouter from "./users.mjs";
import productsRouter from "./products.mjs";
import OrdersRouter from "./orders.mjs";
import bookingsRouter from "./bookings.mjs";

const router = Router();

router.use(usersRouter);
router.use(productsRouter);
router.use(OrdersRouter);
router.use(bookingsRouter);

export default router;